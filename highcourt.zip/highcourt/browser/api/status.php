<?php
declare(strict_types=1);
require __DIR__ . '/_lib.php';

$store = load_store();

$base = rtrim((string) $config['public_url'], '/');
if ($base === '') {
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    $host = preg_replace('/[^A-Za-z0-9.\-:]/', '', (string) ($_SERVER['HTTP_HOST'] ?? 'localhost'));
    $base = ($https ? 'https' : 'http') . '://' . $host;
    // App folder on the site, e.g. /highcourt (this script lives in <app>/api/).
    $base .= rtrim(str_replace('\\', '/', dirname(dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/api/status.php')))), '/');
}

send_json([
    'count' => count($store['voters']),
    'updatedAt' => $store['updatedAt'],
    'file' => 'api/data/' . basename($config['excel_file']),
    'skipped' => $store['skipped'],
    'error' => $store['error'],
    'scanUrl' => $base . '/scan',
]);
