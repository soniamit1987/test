<?php
// Shared helpers for the PHP API (used on hosts without Node.js, e.g. cPanel shared hosting).

declare(strict_types=1);

$config = require __DIR__ . '/_config.php';

const COLUMNS = [
    'enrollmentNumber' => 'enrollment number',
    'name' => 'name',
    'mobileNumber' => 'mobile number',
    'electionBoothDetails' => 'election booth details',
];

function send_json(array $data, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

// Ignore separators so R-3456-2018, R/3456/2018, R 3456 2018 all match.
function norm_enrollment(string $v): string
{
    return preg_replace('/[^A-Z0-9]/', '', strtoupper($v));
}

function norm_mobile(string $v): string
{
    return (string) substr(preg_replace('/\D/', '', $v), -10);
}

function col_index(string $cellRef): int
{
    $letters = preg_replace('/[^A-Z]/', '', strtoupper($cellRef));
    $n = 0;
    for ($i = 0; $i < strlen($letters); $i++) {
        $n = $n * 26 + (ord($letters[$i]) - 64);
    }
    return $n;
}

function xml_text(SimpleXMLElement $node): string
{
    // Concatenate every <t> (handles rich-text runs).
    $out = '';
    foreach ($node->xpath('.//*[local-name()="t"]') as $t) {
        $out .= (string) $t;
    }
    return $out;
}

/** Reads the first worksheet of an .xlsx file into rows of [colIndex => string]. */
function read_xlsx_rows(string $file): array
{
    if (!class_exists('ZipArchive')) {
        throw new RuntimeException('PHP zip extension is not enabled on this server.');
    }
    $zip = new ZipArchive();
    if ($zip->open($file) !== true) {
        throw new RuntimeException('Could not open the Excel file (is it a valid .xlsx?).');
    }

    $shared = [];
    $ssXml = $zip->getFromName('xl/sharedStrings.xml');
    if ($ssXml !== false) {
        $ss = simplexml_load_string($ssXml);
        foreach ($ss->xpath('//*[local-name()="si"]') as $si) {
            $shared[] = xml_text($si);
        }
    }

    $sheetPath = 'xl/worksheets/sheet1.xml';
    $wbXml = $zip->getFromName('xl/workbook.xml');
    $relsXml = $zip->getFromName('xl/_rels/workbook.xml.rels');
    if ($wbXml !== false && $relsXml !== false) {
        $wb = simplexml_load_string($wbXml);
        $first = $wb->xpath('//*[local-name()="sheet"]')[0] ?? null;
        if ($first !== null) {
            $rid = (string) $first->attributes('http://schemas.openxmlformats.org/officeDocument/2006/relationships')['id'];
            $rels = simplexml_load_string($relsXml);
            foreach ($rels->xpath('//*[local-name()="Relationship"]') as $rel) {
                if ((string) $rel['Id'] === $rid) {
                    $target = ltrim((string) $rel['Target'], '/');
                    $sheetPath = strpos($target, 'xl/') === 0 ? $target : 'xl/' . $target;
                }
            }
        }
    }

    $sheetXml = $zip->getFromName($sheetPath);
    $zip->close();
    if ($sheetXml === false) {
        throw new RuntimeException('The workbook has no readable sheet.');
    }

    $sheet = simplexml_load_string($sheetXml);
    $rows = [];
    $rowNum = 0;
    foreach ($sheet->xpath('//*[local-name()="sheetData"]/*[local-name()="row"]') as $row) {
        // Some generators omit the r attribute; fall back to position.
        $rowNum = isset($row['r']) ? (int) $row['r'] : $rowNum + 1;
        $r = $rowNum;
        $cells = [];
        $colNum = 0;
        foreach ($row->xpath('./*[local-name()="c"]') as $c) {
            $colNum = isset($c['r']) ? col_index((string) $c['r']) : $colNum + 1;
            $type = (string) $c['t'];
            $v = $c->xpath('./*[local-name()="v"]');
            $raw = $v ? (string) $v[0] : '';
            if ($type === 's') {
                $val = $shared[(int) $raw] ?? '';
            } elseif ($type === 'inlineStr') {
                $is = $c->xpath('./*[local-name()="is"]');
                $val = $is ? xml_text($is[0]) : '';
            } elseif ($type === '' || $type === 'n') {
                // Large numbers (mobile numbers) may be stored as 9.87654321E+9.
                $val = is_numeric($raw) && floor((float) $raw) == (float) $raw
                    ? sprintf('%.0f', (float) $raw)
                    : $raw;
            } else {
                $val = $raw;
            }
            $cells[$colNum] = trim($val);
        }
        $rows[$r] = $cells;
    }
    return $rows;
}

function parse_voters(string $file): array
{
    $rows = read_xlsx_rows($file);
    $header = $rows[1] ?? [];
    $colIndex = [];
    foreach ($header as $col => $text) {
        $key = preg_replace('/\s+/', ' ', strtolower(trim($text)));
        foreach (COLUMNS as $field => $label) {
            if ($key === $label) {
                $colIndex[$field] = $col;
            }
        }
    }
    $missing = [];
    foreach (COLUMNS as $field => $label) {
        if (!isset($colIndex[$field])) {
            $missing[] = $label;
        }
    }
    if ($missing) {
        throw new RuntimeException('Missing column(s) in row 1: ' . implode(', ', $missing));
    }

    $voters = [];
    $skipped = [];
    $byEnrollment = [];
    $byMobile = [];
    foreach ($rows as $r => $cells) {
        if ($r === 1) {
            continue;
        }
        $get = function (string $f) use ($cells, $colIndex): string {
            return $cells[$colIndex[$f]] ?? '';
        };
        $v = [
            'enrollmentNumber' => strtoupper($get('enrollmentNumber')),
            'name' => $get('name'),
            'mobileNumber' => norm_mobile($get('mobileNumber')),
            'electionBoothDetails' => $get('electionBoothDetails'),
        ];
        if ($v['enrollmentNumber'] === '' && $v['name'] === '' && $v['mobileNumber'] === '') {
            continue;
        }
        if ($v['enrollmentNumber'] === '' || $v['electionBoothDetails'] === '') {
            $skipped[] = ['row' => $r, 'reason' => 'Missing enrollment number or booth details'];
            continue;
        }
        $key = norm_enrollment($v['enrollmentNumber']);
        if (isset($byEnrollment[$key])) {
            $skipped[] = ['row' => $r, 'reason' => 'Duplicate enrollment number ' . $v['enrollmentNumber']];
            continue;
        }
        $i = count($voters);
        $voters[] = $v;
        $byEnrollment[$key] = $i;
        if (strlen($v['mobileNumber']) === 10) {
            $byMobile[$v['mobileNumber']] = $i;
        }
    }
    return compact('voters', 'skipped', 'byEnrollment', 'byMobile');
}

/** Returns parsed data, re-reading the Excel file only when it changes. */
function load_store(): array
{
    global $config;
    $file = $config['excel_file'];
    $empty = ['voters' => [], 'skipped' => [], 'byEnrollment' => [], 'byMobile' => [], 'updatedAt' => null, 'error' => null];

    if (!is_file($file)) {
        return ['error' => 'Excel file not found: ' . basename($file)] + $empty;
    }
    $mtime = filemtime($file);
    $cache = $config['cache_file'];
    if (is_file($cache)) {
        $data = json_decode((string) file_get_contents($cache), true);
        if (is_array($data) && ($data['mtime'] ?? null) === $mtime) {
            return $data;
        }
    }
    try {
        $data = parse_voters($file) + ['mtime' => $mtime, 'updatedAt' => date('c', $mtime), 'error' => null];
        @file_put_contents($cache, json_encode($data, JSON_UNESCAPED_UNICODE), LOCK_EX);
        return $data;
    } catch (Throwable $e) {
        return ['error' => 'Could not read ' . basename($file) . ': ' . $e->getMessage()] + $empty;
    }
}

/** Simple per-IP limit: $limit requests per $window seconds. */
function rate_limit(int $limit, int $window): void
{
    global $config;
    $dir = $config['ratelimit_dir'];
    if (!is_dir($dir) && !@mkdir($dir, 0700, true)) {
        return;
    }
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    $path = $dir . '/' . md5($ip);
    $fh = @fopen($path, 'c+');
    if (!$fh) {
        return;
    }
    flock($fh, LOCK_EX);
    $now = time();
    $hits = array_filter(
        json_decode((string) stream_get_contents($fh), true) ?: [],
        function ($t) use ($now, $window) { return $t > $now - $window; }
    );
    $hits[] = $now;
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode(array_values($hits)));
    flock($fh, LOCK_UN);
    fclose($fh);
    if (count($hits) > $limit) {
        send_json(['error' => 'Too many searches. Please wait a minute and try again.'], 429);
    }
}
