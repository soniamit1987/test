<?php
declare(strict_types=1);
require __DIR__ . '/_lib.php';

rate_limit(30, 60);

$q = (string) substr(trim((string) ($_GET['q'] ?? '')), 0, 50);
if ($q === '') {
    send_json(['error' => 'Enter an Enrollment Number or Mobile Number.'], 400);
}

$store = load_store();
if (!$store['voters']) {
    send_json(['error' => 'The voter list is not available yet. Please contact the Election Committee office.'], 503);
}

$isMobile = (bool) preg_match('/^[+\d\s-]+$/', $q);
$idx = $isMobile
    ? ($store['byMobile'][norm_mobile($q)] ?? null)
    : ($store['byEnrollment'][norm_enrollment($q)] ?? null);

if ($idx === null) {
    send_json(['found' => false]);
}

$v = $store['voters'][$idx];
send_json([
    'found' => true,
    'voter' => [
        'enrollmentNumber' => $v['enrollmentNumber'],
        'name' => $v['name'],
        'mobileNumber' => $v['mobileNumber'] !== '' ? '******' . substr($v['mobileNumber'], -4) : '',
        'electionBoothDetails' => $v['electionBoothDetails'],
    ],
]);
