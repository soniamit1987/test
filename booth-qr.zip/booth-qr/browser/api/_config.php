<?php
// Edit these on the server if needed.
return [
    // Excel voter list. The data/ folder is blocked from web access by .htaccess.
    'excel_file' => __DIR__ . '/data/voters.xlsx',
    'cache_file' => __DIR__ . '/data/voters.cache.json',
    'ratelimit_dir' => __DIR__ . '/data/ratelimit',
    // Address encoded in the QR code. Leave empty to use the current site address.
    'public_url' => '',
];
